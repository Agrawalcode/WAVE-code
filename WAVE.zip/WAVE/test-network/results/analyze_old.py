#!/usr/bin/env python3
"""Generate methodology-correct WAVE metrics and all experiment graphs."""

from __future__ import annotations

import csv
import json
import math
from collections import Counter
from pathlib import Path
from statistics import mean, pstdev
from typing import Any

import matplotlib.pyplot as plt
import numpy as np

BASELINE_CSV = Path("baseline_transactions.csv")
PROPOSED_CSV = Path("proposed_transactions.csv")
BASELINE_BLOCKS = Path("baseline_blocks.json")
PROPOSED_BLOCKS = Path("proposed_blocks.json")


def load_json(path: Path) -> Any:
    value = json.loads(path.read_text(encoding="utf-8").strip())
    if isinstance(value, str):
        value = json.loads(value)
    return value


def load_transactions(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        raise FileNotFoundError(f"Missing {path}")
    rows: list[dict[str, Any]] = []
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            rows.append({
                "transaction": int(row["transaction"]),
                "mode": row["mode"],
                "validator": row["validator"],
                "block_number": int(row["block_number"]),
                "tx_in_block": int(row["tx_in_block"]),
                "success": row["success"].lower() == "true",
                "simulated_latency_s": float(row["simulated_latency_s"]),
                "fabric_confirmation_latency_ms":
                    float(row["fabric_confirmation_latency_ms"]),
            })
    if not rows:
        raise ValueError(f"No transaction data found in {path}")
    return rows


def load_blocks(path: Path, transactions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if path.exists():
        records = load_json(path)
        if records:
            return records

    # Safe fallback reconstructed from transaction CSV.
    grouped: dict[int, list[dict[str, Any]]] = {}
    for row in transactions:
        grouped.setdefault(row["block_number"], []).append(row)

    records = []
    for block_number, rows in sorted(grouped.items()):
        records.append({
            "blockNumber": block_number,
            "validatorId": rows[0]["validator"],
            "txCount": len(rows),
            "blockAvgLatency": mean(r["simulated_latency_s"] for r in rows),
            "blockSuccessRate": mean(1.0 if r["success"] else 0.0 for r in rows),
        })
    return records


def validator_sort_key(validator_id: str) -> tuple[int, str]:
    digits = "".join(ch for ch in validator_id if ch.isdigit())
    return (int(digits) if digits else 10**9, validator_id)


def jain(values: np.ndarray) -> float:
    if values.size == 0 or np.sum(values) == 0:
        return 0.0
    return float(np.sum(values) ** 2 / (len(values) * np.sum(values ** 2)))


def gini(values: np.ndarray) -> float:
    if values.size == 0 or np.sum(values) == 0:
        return 0.0
    ordered = np.sort(values)
    n = len(ordered)
    indices = np.arange(1, n + 1)
    return float(
        (
            2 * np.sum(indices * ordered) -
            (n + 1) * np.sum(ordered)
        ) / (n * np.sum(ordered))
    )


def shannon_entropy(values: np.ndarray) -> float:
    total = np.sum(values)
    if total == 0:
        return 0.0
    shares = values[values > 0] / total
    return float(-np.sum(shares * np.log2(shares)))


def normalized_entropy(values: np.ndarray) -> float:
    if len(values) <= 1:
        return 0.0
    return shannon_entropy(values) / math.log2(len(values))


def nakamoto_coefficient(values: np.ndarray) -> int:
    total = np.sum(values)
    if total == 0:
        return 0
    cumulative = 0.0
    for index, value in enumerate(np.sort(values)[::-1], start=1):
        cumulative += value
        if cumulative > 0.5 * total:
            return index
    return len(values)


def hhi(values: np.ndarray) -> float:
    total = np.sum(values)
    if total == 0:
        return 0.0
    shares = values / total
    return float(np.sum(shares ** 2))


def coefficient_of_variation(values: np.ndarray) -> float:
    if values.size == 0 or np.mean(values) == 0:
        return 0.0
    return float(np.std(values) / np.mean(values))


def max_load_ratio(values: np.ndarray) -> float:
    if values.size == 0 or np.mean(values) == 0:
        return 0.0
    return float(np.max(values) / np.mean(values))


def starvation_count(values: np.ndarray) -> int:
    return int(np.sum(values == 0))


def validator_rotation(block_validators: list[str]) -> float:
    if len(block_validators) <= 1:
        return 0.0
    changes = sum(
        block_validators[index] != block_validators[index - 1]
        for index in range(1, len(block_validators))
    )
    return changes / (len(block_validators) - 1)


def moving_average(values: np.ndarray, window: int = 20) -> tuple[np.ndarray, np.ndarray]:
    if values.size == 0:
        return np.array([]), np.array([])
    effective_window = min(window, values.size)
    kernel = np.ones(effective_window) / effective_window
    smoothed = np.convolve(values, kernel, mode="valid")
    x_values = np.arange(effective_window, values.size + 1)
    return x_values, smoothed


def lorenz_curve(values: np.ndarray) -> np.ndarray:
    ordered = np.sort(values)
    cumulative = np.cumsum(ordered)
    if cumulative.size == 0 or cumulative[-1] == 0:
        return np.zeros(len(values) + 1)
    return np.insert(cumulative / cumulative[-1], 0, 0)


baseline_tx = load_transactions(BASELINE_CSV)
proposed_tx = load_transactions(PROPOSED_CSV)
baseline_blocks = load_blocks(BASELINE_BLOCKS, baseline_tx)
proposed_blocks = load_blocks(PROPOSED_BLOCKS, proposed_tx)

baseline_block_validators = [str(row["validatorId"]) for row in baseline_blocks]
proposed_block_validators = [str(row["validatorId"]) for row in proposed_blocks]

# Use all registered validator IDs, including idle validators.
validator_ids = [f"V{i}" for i in range(1, 51)]
observed = set(baseline_block_validators) | set(proposed_block_validators)
validator_ids = sorted(set(validator_ids) | observed, key=validator_sort_key)

baseline_counts = Counter(baseline_block_validators)
proposed_counts = Counter(proposed_block_validators)

baseline_values = np.array(
    [baseline_counts.get(v, 0) for v in validator_ids],
    dtype=float,
)
proposed_values = np.array(
    [proposed_counts.get(v, 0) for v in validator_ids],
    dtype=float,
)

baseline_fabric_latency = np.array(
    [row["fabric_confirmation_latency_ms"] for row in baseline_tx],
    dtype=float,
)
proposed_fabric_latency = np.array(
    [row["fabric_confirmation_latency_ms"] for row in proposed_tx],
    dtype=float,
)

metrics = {
    "Jain Fairness Index": (
        jain(baseline_values),
        jain(proposed_values),
    ),
    "Gini Coefficient": (
        gini(baseline_values),
        gini(proposed_values),
    ),
    "Shannon Entropy (bits)": (
        shannon_entropy(baseline_values),
        shannon_entropy(proposed_values),
    ),
    "Normalized Entropy": (
        normalized_entropy(baseline_values),
        normalized_entropy(proposed_values),
    ),
    "Nakamoto Coefficient": (
        nakamoto_coefficient(baseline_values),
        nakamoto_coefficient(proposed_values),
    ),
    "HHI": (
        hhi(baseline_values),
        hhi(proposed_values),
    ),
    "Coeff. of Variation": (
        coefficient_of_variation(baseline_values),
        coefficient_of_variation(proposed_values),
    ),
    "Max Load Ratio": (
        max_load_ratio(baseline_values),
        max_load_ratio(proposed_values),
    ),
    "Starvation Count": (
        starvation_count(baseline_values),
        starvation_count(proposed_values),
    ),
    "Validator Rotation": (
        validator_rotation(baseline_block_validators),
        validator_rotation(proposed_block_validators),
    ),
    "Avg Fabric Latency (ms)": (
        float(np.mean(baseline_fabric_latency)),
        float(np.mean(proposed_fabric_latency)),
    ),
    "Fabric Latency Std Dev (ms)": (
        float(np.std(baseline_fabric_latency)),
        float(np.std(proposed_fabric_latency)),
    ),
}

print("\n" + "=" * 72)
print(f"{'Metric':<32}{'Baseline':>18}{'Proposed':>18}")
print("=" * 72)
for name, (baseline_value, proposed_value) in metrics.items():
    if name in {"Starvation Count", "Nakamoto Coefficient"}:
        print(
            f"{name:<32}{int(baseline_value):>18d}"
            f"{int(proposed_value):>18d}"
        )
    else:
        print(
            f"{name:<32}{baseline_value:>18.4f}"
            f"{proposed_value:>18.4f}"
        )
print("=" * 72)

with Path("metrics_summary.csv").open(
    "w",
    newline="",
    encoding="utf-8",
) as handle:
    writer = csv.writer(handle)
    writer.writerow(["metric", "baseline", "proposed"])
    for name, values in metrics.items():
        writer.writerow([name, values[0], values[1]])

with Path("validator_block_selection_counts.csv").open(
    "w",
    newline="",
    encoding="utf-8",
) as handle:
    writer = csv.writer(handle)
    writer.writerow(["validator", "baseline_blocks", "proposed_blocks"])
    for validator_id, baseline_count, proposed_count in zip(
        validator_ids,
        baseline_values,
        proposed_values,
    ):
        writer.writerow([
            validator_id,
            int(baseline_count),
            int(proposed_count),
        ])

# Mann-Whitney U test on per-transaction Fabric confirmation latency.
try:
    from scipy.stats import mannwhitneyu
    statistic, p_value = mannwhitneyu(
        baseline_fabric_latency,
        proposed_fabric_latency,
        alternative="two-sided",
    )
    with Path("statistical_test.txt").open("w", encoding="utf-8") as handle:
        handle.write(f"Mann-Whitney U statistic: {statistic}\n")
        handle.write(f"p-value: {p_value}\n")
except ImportError:
    Path("statistical_test.txt").write_text(
        "scipy is not installed; Mann-Whitney U test was skipped.\n",
        encoding="utf-8",
    )

# 1. Rank plot — actual block assignments.
baseline_sorted = np.sort(baseline_values)[::-1]
proposed_sorted = np.sort(proposed_values)[::-1]
baseline_pct = (
    baseline_sorted / np.sum(baseline_sorted) * 100
    if np.sum(baseline_sorted) else baseline_sorted
)
proposed_pct = (
    proposed_sorted / np.sum(proposed_sorted) * 100
    if np.sum(proposed_sorted) else proposed_sorted
)

plt.figure(figsize=(8, 4))
plt.plot(baseline_pct, label="Baseline", marker="o", markersize=3, linewidth=2)
plt.plot(proposed_pct, label="Proposed", marker="o", markersize=3, linewidth=2)
plt.xlabel("Validator rank",fontsize=14,
    fontweight="bold")
plt.ylabel("Application-block selection share (%)", fontsize=14,
    fontweight="bold")
plt.title("Validator block-selection rank distribution",fontsize=18,)
plt.legend(fontsize=12)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("rank_plot.png", dpi=600, bbox_inches="tight")
plt.close()

# 2. Lorenz curve.
baseline_lorenz = lorenz_curve(baseline_values)
proposed_lorenz = lorenz_curve(proposed_values)

plt.figure(figsize=(5, 5))
plt.plot(
    np.linspace(0, 1, len(baseline_lorenz)),
    baseline_lorenz,
    label=f"Baseline (Gini={gini(baseline_values):.3f})", linewidth=2,
)
plt.plot(
    np.linspace(0, 1, len(proposed_lorenz)),
    proposed_lorenz,
    label=f"Proposed (Gini={gini(proposed_values):.3f})", linewidth=2,
)
plt.plot([0, 1], [0, 1], linestyle="--", label="Perfect equality", linewidth=2)
plt.xlabel("Cumulative validators",fontsize=14,
    fontweight="bold")
plt.ylabel("Cumulative block-selection share", fontsize=14,
    fontweight="bold")
plt.title("Lorenz curve",fontsize=18,)
plt.legend(fontsize=12)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("lorenz.png", dpi=600, bbox_inches="tight")
plt.close()

# 3. Latency comparison — robust even for fewer than 20 transactions.
baseline_x, baseline_smooth = moving_average(baseline_fabric_latency, 20)
proposed_x, proposed_smooth = moving_average(proposed_fabric_latency, 20)

plt.figure(figsize=(9, 4))
plt.plot(
    baseline_x,
    baseline_smooth,
    label="Baseline",
    linestyle="--", linewidth=2,
)
plt.plot(
    proposed_x,
    proposed_smooth,
    label="Proposed", linewidth=2,
)
plt.axhline(
    np.mean(baseline_fabric_latency), color="#ef6358",
    linestyle=":",
    label=f"Baseline mean ({np.mean(baseline_fabric_latency):.1f} ms)",
)
plt.axhline(
    np.mean(proposed_fabric_latency),  color="#4dcc7d",
    linestyle=":",
    label=f"Proposed mean ({np.mean(proposed_fabric_latency):.1f} ms)",
)
plt.xlabel("Transaction",fontsize=14,
    fontweight="bold")
plt.ylabel("Fabric confirmation latency (ms)", fontsize=14,
    fontweight="bold")
plt.title("Transaction-confirmation latency",fontsize=18,)
plt.legend(fontsize=12)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("latency.png", dpi=600, bbox_inches="tight")
plt.close()

# 4. Validator distribution.
x_positions = np.arange(len(validator_ids))
width = 0.6

plt.figure(figsize=(20, 5))
plt.bar(
    x_positions - width / 2,
    baseline_values,
    width,
    label="Baseline",
)
plt.bar(
    x_positions + width / 2,
    proposed_values,
    width,
    label="Proposed",
)
plt.xlabel("Validator",fontsize=18,
    fontweight="bold")
plt.ylabel("Application blocks assigned", fontsize=18,
    fontweight="bold")
plt.title("Validator block-selection distribution",fontsize=22,)
plt.xticks(x_positions, validator_ids, rotation=90, fontsize=12)
plt.legend(fontsize=18)
plt.grid(alpha=0.2, axis="y")
plt.tight_layout()
plt.savefig("distribution.png", dpi=800, bbox_inches="tight")
plt.close()

# 5. Cumulative selection.
baseline_cumulative = (
    np.cumsum(baseline_sorted) / np.sum(baseline_sorted)
    if np.sum(baseline_sorted) else baseline_sorted
)
proposed_cumulative = (
    np.cumsum(proposed_sorted) / np.sum(proposed_sorted)
    if np.sum(proposed_sorted) else proposed_sorted
)

plt.figure(figsize=(8, 4))
plt.step(
    range(len(baseline_cumulative)),
    baseline_cumulative,
    where="post",
    label="Baseline",
)
plt.plot(proposed_cumulative, label="Proposed", linewidth=2)
plt.xlabel("Validators sorted by block assignments",fontsize=14,
    fontweight="bold")
plt.ylabel("Cumulative block-selection share", fontsize=14,
    fontweight="bold")
plt.title("Cumulative validator block selection",fontsize=18,)
plt.legend(fontsize=12)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("cumulative.png", dpi=600, bbox_inches="tight")
plt.close()

# 6. Metrics comparison.
fig, axes = plt.subplots(2, 3, figsize=(14, 8))
comparison = [
    ("Jain Fairness\nIndex", "Jain Fairness Index", "higher=better"),
    ("Gini\nCoefficient", "Gini Coefficient", "lower=better"),
    ("Normalized\nEntropy", "Normalized Entropy", "higher=better"),
    ("Nakamoto\nCoefficient", "Nakamoto Coefficient", "higher=better"),
    ("HHI", "HHI", "lower=better"),
    ("Validator\nRotation", "Validator Rotation", "higher=better"),
]

for index, (label, key, note) in enumerate(comparison):
    axis = axes[index // 3, index % 3]
    baseline_value, proposed_value = metrics[key]
    bars = axis.bar(
        ["Baseline", "Proposed"],
        [baseline_value, proposed_value],
        color=["#ef6358", "#4dcc7d"],
    )
    axis.tick_params(axis='x', labelsize=16)  # Increase x-axis label font
    axis.tick_params(axis='y', labelsize=16)
    axis.set_title(f"{label}\n({note})", fontsize=15, fontweight="bold")
    axis.grid(alpha=0.2, axis="y")

    maximum = max(float(baseline_value), float(proposed_value))
    axis.set_ylim(0, maximum * 1.25 if maximum > 0 else 1)

    for bar, value in zip(bars, [baseline_value, proposed_value]):
        text = (
            f"{int(value)}"
            if key == "Nakamoto Coefficient"
            else f"{value:.4f}"
        )
        axis.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + (maximum * 0.03 if maximum > 0 else 0.02),
            text,
            ha="center",
            va="bottom",
            fontsize=12,
            fontweight="bold",
        )

fig.suptitle("Evaluation Metrics Comparison", fontsize=18)
plt.tight_layout(rect=(0, 0, 1, 0.96))
plt.savefig("metrics_comparison.png", dpi=800, bbox_inches="tight")
plt.close()

print("\nGenerated:")
for filename in [
    "rank_plot.png",
    "lorenz.png",
    "latency.png",
    "distribution.png",
    "cumulative.png",
    "metrics_comparison.png",
    "metrics_summary.csv",
    "validator_block_selection_counts.csv",
]:
    print(f"  {filename}")
