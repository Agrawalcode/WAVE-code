#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-proposed}"
NUM_TX="${2:-500}"

if [[ "$MODE" != "baseline" && "$MODE" != "proposed" ]]; then
    echo "MODE must be baseline or proposed" >&2
    exit 2
fi

if ! [[ "$NUM_TX" =~ ^[1-9][0-9]*$ ]]; then
    echo "NUM_TX must be a positive integer" >&2
    exit 2
fi

RESULTS_DIR="../results"
LOG_FILE="${RESULTS_DIR}/${MODE}_log.txt"
CSV_FILE="${RESULTS_DIR}/${MODE}_transactions.csv"

mkdir -p "$RESULTS_DIR"
: > "$LOG_FILE"

printf '%s\n' \
  "transaction,mode,validator,block_number,tx_in_block,success,simulated_latency_s,fabric_confirmation_latency_ms" \
  > "$CSV_FILE"

echo "Running experiment: MODE=$MODE | NUM_TX=$NUM_TX" >> "$LOG_FILE"

for ((i=1; i<=NUM_TX; i++)); do
    START_NS=$(date +%s%N)

    BUYER="EV$(( (i % 3) + 1 ))"
    SELLER="EV$(( ((i + 1) % 3) + 4 ))"

    # Reproducible 80% success rate.
    if (( i % 5 == 0 )); then
        SUCCESS="false"
    else
        SUCCESS="true"
    fi

    # Reproducible synthetic validator latency: 0.05 to 0.95 seconds.
    LATENCY_MS=$((50 + ((i * 137) % 19) * 50))
    SIM_LATENCY=$(python3 -c \
      "print(f'{$LATENCY_MS / 1000:.3f}')")

    PAYLOAD_JSON=$(python3 - "$BUYER" "$SELLER" "$SUCCESS" \
      "$SIM_LATENCY" "$MODE" <<'PY'
import json, sys
buyer, seller, success, latency, mode = sys.argv[1:]
print(json.dumps({
    "function": "completeTransaction",
    "Args": [buyer, seller, success, latency, mode],
}))
PY
)

    set +e
    RESULT=$(peer chaincode invoke -o localhost:7050 \
      --ordererTLSHostnameOverride orderer.example.com \
      --tls --cafile "$ORDERER_CA" \
      --waitForEvent \
      -C mychannel -n v2v \
      -c "$PAYLOAD_JSON" 2>&1)
    STATUS=$?
    set -e

    END_NS=$(date +%s%N)
    FABRIC_LATENCY_MS=$(( (END_NS - START_NS) / 1000000 ))

    if (( STATUS != 0 )); then
        echo "Transaction $i failed:" >&2
        echo "$RESULT" >&2
        exit "$STATUS"
    fi

    PARSED=$(python3 - "$RESULT" <<'PY'
import codecs, json, re, sys

text = sys.argv[1]
match = re.search(r'payload:"((?:\\.|[^"])*)"', text, re.S)
if not match:
    match = re.search(r'payload:\s*(\{.*\})', text, re.S)

if not match:
    raise SystemExit("Could not locate chaincode payload in peer output")

raw = match.group(1)
try:
    decoded = codecs.decode(raw, "unicode_escape")
except Exception:
    decoded = raw

obj = json.loads(decoded)
print(
    obj.get("validatorUsed", ""),
    obj.get("blockNumber", ""),
    obj.get("txInBlock", ""),
    sep="\t",
)
PY
)

    IFS=$'\t' read -r VALIDATOR BLOCK_NUMBER TX_IN_BLOCK <<< "$PARSED"

    if [[ -z "$VALIDATOR" || -z "$BLOCK_NUMBER" ]]; then
        echo "Could not parse validator/block from transaction $i" >&2
        echo "$RESULT" >&2
        exit 1
    fi

    echo \
      "Tx $i | Validator: $VALIDATOR | Block: $BLOCK_NUMBER | TxInBlock: $TX_IN_BLOCK | FabricLatency(ms): $FABRIC_LATENCY_MS | SimLatency(s): $SIM_LATENCY" \
      >> "$LOG_FILE"

    printf '%s,%s,%s,%s,%s,%s,%s,%s\n' \
      "$i" "$MODE" "$VALIDATOR" "$BLOCK_NUMBER" "$TX_IN_BLOCK" \
      "$SUCCESS" "$SIM_LATENCY" "$FABRIC_LATENCY_MS" \
      >> "$CSV_FILE"
done

echo "Experiment $MODE completed. Results: $LOG_FILE and $CSV_FILE"
