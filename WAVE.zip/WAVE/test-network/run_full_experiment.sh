#!/usr/bin/env bash
set -euo pipefail

NUM_TX="${1:-500}"
VALIDATOR_COUNT="${VALIDATOR_COUNT:-50}"
BLOCK_SIZE=20

echo "===================================================="
echo "  WAVE application-layer experiment"
echo "  Transactions per mode: $NUM_TX"
echo "  Validators: $VALIDATOR_COUNT | App block size: $BLOCK_SIZE"
echo "===================================================="

export PATH="${PWD}/../bin:$PATH"
export FABRIC_CFG_PATH="${PWD}/../config/"
export CORE_PEER_TLS_ENABLED=true
export CORE_PEER_LOCALMSPID="Org1MSP"
export CORE_PEER_TLS_ROOTCERT_FILE="${PWD}/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt"
export CORE_PEER_MSPCONFIGPATH="${PWD}/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp"
export CORE_PEER_ADDRESS=localhost:7051
export ORDERER_CA="${PWD}/organizations/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem"

invoke() {
    peer chaincode invoke -o localhost:7050 \
      --ordererTLSHostnameOverride orderer.example.com \
      --tls --cafile "$ORDERER_CA" \
      --waitForEvent \
      -C mychannel -n v2v \
      -c "$1"
}

query_to_file() {
    local payload="$1"
    local output="$2"
    peer chaincode query -C mychannel -n v2v -c "$payload" > "$output"
}

mkdir -p results

echo "Registering EVs..."
for i in {1..6}; do
    invoke "{\"function\":\"registerEV\",\"Args\":[\"EV$i\"]}" \
      >/dev/null 2>&1 || true
done

echo "Registering validators..."
for ((i=1; i<=VALIDATOR_COUNT; i++)); do
    invoke "{\"function\":\"registerValidator\",\"Args\":[\"V$i\",\"100\"]}" \
      >/dev/null 2>&1 || true
done

echo "Resetting experiment state before baseline..."
invoke '{"function":"resetAllValidators","Args":["all"]}'

echo "Running BASELINE..."
(
    cd scripts
    bash run_experiment.sh baseline "$NUM_TX"
)

invoke '{"function":"finalizeCurrentBlock","Args":["baseline"]}'
query_to_file \
  '{"function":"getBlockRecords","Args":["baseline"]}' \
  results/baseline_blocks.json
query_to_file \
  '{"function":"getAllValidators","Args":[]}' \
  results/baseline_validators.json

echo "Resetting validator statistics before proposed run..."
# Clears both modes' ledger experiment records. Baseline data are already
# exported to files above.
invoke '{"function":"resetAllValidators","Args":["all"]}'

echo "Running PROPOSED..."
(
    cd scripts
    bash run_experiment.sh proposed "$NUM_TX"
)

invoke '{"function":"finalizeCurrentBlock","Args":["proposed"]}'
query_to_file \
  '{"function":"getBlockRecords","Args":["proposed"]}' \
  results/proposed_blocks.json
query_to_file \
  '{"function":"getAllValidators","Args":[]}' \
  results/proposed_validators.json

echo "Running analysis..."
PYTHON_BIN="${PYTHON_BIN:-python3}"

# Prefer the project-level virtual environment created as:
# python3 -m venv ~/WAVE-Energy-Trading-modified/.venv
PROJECT_ROOT="$(cd .. && pwd)"

if [[ -x "$PROJECT_ROOT/.venv/bin/python" ]]; then
    PYTHON_BIN="$PROJECT_ROOT/.venv/bin/python"
fi

(
    cd results
    "$PYTHON_BIN" analyze.py
)

echo "===================================================="
echo "Completed. Graphs and CSVs are in test-network/results/"
echo "===================================================="
