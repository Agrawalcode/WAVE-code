'use strict';

const { Contract } = require('fabric-contract-api');
const crypto = require('crypto');

const BLOCK_SIZE = 20;
const EPSILON = 0.05;

function getValidatorKey(id) {
    return `VALIDATOR_${id}`;
}

function getBlockStateKey(mode) {
    return `CURRENT_BLOCK_${mode}`;
}

function getBlockRecordKey(mode, blockNumber) {
    return `BLOCK_${mode}_${String(blockNumber).padStart(8, '0')}`;
}

class V2VContract extends Contract {

    async initLedger(ctx) {
        return JSON.stringify({
            message: 'Ledger initialized',
            scope: 'application-layer validator assignment',
            blockSize: BLOCK_SIZE
        });
    }

    async registerEV(ctx, evId) {
        const exists = await ctx.stub.getState(evId);
        if (exists && exists.length > 0) {
            throw new Error('EV already registered');
        }

        const ev = {
            id: evId,
            reputation: 0,
            totalTrades: 0,
            successfulTrades: 0,
            avgLatency: 0,
            lastLatency: 0
        };

        await ctx.stub.putState(evId, Buffer.from(JSON.stringify(ev)));
        return JSON.stringify(ev);
    }

    async registerValidator(ctx, validatorId, energy) {
        const key = getValidatorKey(validatorId);
        const exists = await ctx.stub.getState(key);

        if (exists && exists.length > 0) {
            throw new Error('Validator already exists');
        }

        const validator = {
            id: validatorId,
            reputation: 0,
            totalValidations: 0,
            successfulValidations: 0,
            successRate: 0,
            avgLatency: 0,
            lastLatency: 0,
            energy: Number(energy),
            selectionCount: 0,
            completedBlocks: 0,
            lastCorrectnessScore: 0,
            lastLatencyScore: 0,
            lastHistoryScore: 0,
            lastReward: 0
        };

        await ctx.stub.putState(key, Buffer.from(JSON.stringify(validator)));
        return JSON.stringify(validator);
    }

    async finalizeTrade(ctx, buyerId, sellerId, success) {
        const buyerBytes = await ctx.stub.getState(buyerId);
        const sellerBytes = await ctx.stub.getState(sellerId);

        if (!buyerBytes || buyerBytes.length === 0 ||
            !sellerBytes || sellerBytes.length === 0) {
            throw new Error('EV not found');
        }

        const buyer = JSON.parse(buyerBytes.toString());
        const seller = JSON.parse(sellerBytes.toString());
        const isSuccessful = success === true || success === 'true';

        buyer.totalTrades += 1;
        seller.totalTrades += 1;

        if (isSuccessful) {
            buyer.successfulTrades += 1;
            seller.successfulTrades += 1;
        }

        const buyerRate = buyer.successfulTrades / buyer.totalTrades;
        const sellerRate = seller.successfulTrades / seller.totalTrades;

        buyer.reputation = 0.6 * buyer.reputation + 0.4 * buyerRate;
        seller.reputation = 0.6 * seller.reputation + 0.4 * sellerRate;

        await ctx.stub.putState(buyerId, Buffer.from(JSON.stringify(buyer)));
        await ctx.stub.putState(sellerId, Buffer.from(JSON.stringify(seller)));

        return JSON.stringify({
            buyer: { id: buyer.id, reputation: buyer.reputation },
            seller: { id: seller.id, reputation: seller.reputation }
        });
    }

    async updateValidatorForBlock(
        ctx,
        validatorId,
        blockTxCount,
        blockTotalLatency,
        blockSuccessCount
    ) {
        const key = getValidatorKey(validatorId);
        const bytes = await ctx.stub.getState(key);

        if (!bytes || bytes.length === 0) {
            throw new Error(`Validator ${validatorId} not found`);
        }

        const validator = JSON.parse(bytes.toString());
        const txCount = Number(blockTxCount);
        const totalLatency = Number(blockTotalLatency);
        const successCount = Number(blockSuccessCount);

        if (!Number.isInteger(txCount) || txCount <= 0) {
            throw new Error('blockTxCount must be a positive integer');
        }
        if (!Number.isFinite(totalLatency) || totalLatency < 0) {
            throw new Error('blockTotalLatency must be non-negative');
        }
        if (!Number.isInteger(successCount) ||
            successCount < 0 || successCount > txCount) {
            throw new Error('blockSuccessCount is invalid');
        }

        const previousValidations = validator.totalValidations;
        validator.totalValidations += txCount;
        validator.successfulValidations += successCount;
        validator.successRate =
            validator.successfulValidations / validator.totalValidations;

        validator.avgLatency =
            (
                validator.avgLatency * previousValidations +
                totalLatency
            ) / validator.totalValidations;

        validator.lastLatency = totalLatency / txCount;

        // Paper-aligned block-level components.
        const correctnessScore = successCount / txCount;
        const latencyScore = 1 / (1 + validator.lastLatency);
        const historyScore = validator.successRate;

        const reward =
            0.5 * correctnessScore +
            0.3 * latencyScore +
            0.2 * historyScore;

        validator.reputation =
            0.7 * validator.reputation + 0.3 * reward;
        validator.reputation = Math.max(-1, Math.min(1, validator.reputation));

        validator.completedBlocks += 1;
        validator.lastCorrectnessScore = correctnessScore;
        validator.lastLatencyScore = latencyScore;
        validator.lastHistoryScore = historyScore;
        validator.lastReward = reward;

        await ctx.stub.putState(key, Buffer.from(JSON.stringify(validator)));

        return {
            validatorId,
            correctnessScore,
            latencyScore,
            historyScore,
            reward,
            updatedReputation: validator.reputation,
            successRate: validator.successRate,
            avgLatency: validator.avgLatency
        };
    }

    async selectValidator(ctx, mode) {
        mode = mode || 'proposed';
        mode = this._normalizeMode(mode);
        const validators = await this._getValidatorObjects(ctx);

        if (validators.length === 0) {
            throw new Error('No validators available');
        }

        validators.sort((a, b) => this._compareValidatorIds(a.id, b.id));

        if (mode === 'baseline') {
            validators.sort((a, b) => {
                const reputationDifference =
                    Number(b.reputation) - Number(a.reputation);
                if (reputationDifference !== 0) {
                    return reputationDifference;
                }
                return this._compareValidatorIds(a.id, b.id);
            });
            return JSON.stringify(validators[0]);
        }

        const weighted = validators.map(validator => ({
            validator,
            score: Math.max(Number(validator.reputation) || 0, EPSILON)
        }));
        const totalScore = weighted.reduce(
            (sum, item) => sum + item.score,
            0
        );

        // Deterministic random fraction: every endorsing peer receives the
        // same transaction ID and ledger state, so endorsement remains valid.
        const stateText = weighted.map(item =>
            `${item.validator.id}:${Number(item.validator.reputation).toFixed(12)}`
        ).join('|');
        const seed = `${ctx.stub.getChannelID()}|${ctx.stub.getTxID()}|${mode}|${stateText}`;
        const fraction = this._deterministicFraction(seed);
        let threshold = fraction * totalScore;

        for (const item of weighted) {
            threshold -= item.score;
            if (threshold <= 0) {
                return JSON.stringify(item.validator);
            }
        }

        return JSON.stringify(weighted[weighted.length - 1].validator);
    }

    async validateTransaction(ctx, validatorId, latency, isCorrect) {
        const latencyValue = Number(latency);
        const valid = isCorrect === true || isCorrect === 'true';
        const result = await this.updateValidatorForBlock(
            ctx,
            validatorId,
            1,
            latencyValue,
            valid ? 1 : 0
        );
        return JSON.stringify(result);
    }

    async completeTransaction(
        ctx,
        buyerId,
        sellerId,
        success,
        latency,
        mode
    ) {
        mode = mode || 'proposed';
        mode = this._normalizeMode(mode);
        const isValid = success === true || success === 'true';
        const latencyValue = Number(latency);

        if (!Number.isFinite(latencyValue) || latencyValue < 0) {
            throw new Error('latency must be a non-negative number');
        }

        const blockKey = getBlockStateKey(mode);
        const blockBytes = await ctx.stub.getState(blockKey);
        let blockState = null;

        if (blockBytes && blockBytes.length > 0) {
            blockState = JSON.parse(blockBytes.toString());
        }

        if (!blockState) {
            const selected = JSON.parse(await this.selectValidator(ctx, mode));
            blockState = {
                type: 'ACTIVE_APPLICATION_BLOCK',
                mode,
                blockNumber: 1,
                validatorId: selected.id,
                txCount: 0,
                totalLatency: 0,
                successCount: 0,
                failCount: 0
            };
        }

        await this.finalizeTrade(ctx, buyerId, sellerId, isValid);

        blockState.txCount += 1;
        blockState.totalLatency += latencyValue;
        if (isValid) {
            blockState.successCount += 1;
        } else {
            blockState.failCount += 1;
        }

        const response = {
            message: 'Transaction completed',
            mode,
            validatorUsed: blockState.validatorId,
            blockNumber: blockState.blockNumber,
            txInBlock: blockState.txCount,
            blockSize: BLOCK_SIZE,
            blockFinalized: false
        };

        if (blockState.txCount >= BLOCK_SIZE) {
            const record = await this._finalizeBlockState(ctx, blockState);
            response.blockFinalized = true;
            response.finalizedBlock = record;

            const selected = JSON.parse(await this.selectValidator(ctx, mode));
            const nextState = {
                type: 'ACTIVE_APPLICATION_BLOCK',
                mode,
                blockNumber: blockState.blockNumber + 1,
                validatorId: selected.id,
                txCount: 0,
                totalLatency: 0,
                successCount: 0,
                failCount: 0
            };
            await ctx.stub.putState(
                blockKey,
                Buffer.from(JSON.stringify(nextState))
            );
        } else {
            await ctx.stub.putState(
                blockKey,
                Buffer.from(JSON.stringify(blockState))
            );
        }

        return JSON.stringify(response);
    }

    async finalizeCurrentBlock(ctx, mode) {
        mode = mode || 'proposed';
        mode = this._normalizeMode(mode);
        const blockKey = getBlockStateKey(mode);
        const blockBytes = await ctx.stub.getState(blockKey);

        if (!blockBytes || blockBytes.length === 0) {
            return JSON.stringify({
                message: `No active ${mode} block to finalize`
            });
        }

        const blockState = JSON.parse(blockBytes.toString());

        if (blockState.txCount === 0) {
            await ctx.stub.deleteState(blockKey);
            return JSON.stringify({
                message: `No active ${mode} block to finalize`
            });
        }

        const record = await this._finalizeBlockState(ctx, blockState);
        await ctx.stub.deleteState(blockKey);

        return JSON.stringify({
            message: `Finalized ${mode} block ${blockState.blockNumber}`,
            blockRecord: record
        });
    }

    async getAllValidators(ctx) {
        return JSON.stringify(await this._getValidatorObjects(ctx));
    }

    async getBlockRecords(ctx, mode) {
        mode = mode || 'proposed';
        mode = this._normalizeMode(mode);
        const prefix = `BLOCK_${mode}_`;
        const iterator = await ctx.stub.getStateByRange(prefix, `${prefix}\uffff`);
        const records = [];

        while (true) {
            const item = await iterator.next();
            if (item.value && item.value.value) {
                records.push(JSON.parse(item.value.value.toString()));
            }
            if (item.done) {
                await iterator.close();
                break;
            }
        }

        records.sort((a, b) => a.blockNumber - b.blockNumber);
        return JSON.stringify(records);
    }

    async resetAllValidators(ctx, mode) {
        mode = mode || 'all';
        const iterator = await ctx.stub.getStateByRange('', '');
        const keysToDelete = [];
        let validatorCount = 0;

        while (true) {
            const item = await iterator.next();

            if (item.value && item.value.key) {
                const key = item.value.key;

                if (key.startsWith('VALIDATOR_')) {
                    const validator = JSON.parse(
                        item.value.value.toString()
                    );
                    validator.reputation = 0;
                    validator.totalValidations = 0;
                    validator.successfulValidations = 0;
                    validator.successRate = 0;
                    validator.avgLatency = 0;
                    validator.lastLatency = 0;
                    validator.selectionCount = 0;
                    validator.completedBlocks = 0;
                    validator.lastCorrectnessScore = 0;
                    validator.lastLatencyScore = 0;
                    validator.lastHistoryScore = 0;
                    validator.lastReward = 0;

                    await ctx.stub.putState(
                        key,
                        Buffer.from(JSON.stringify(validator))
                    );
                    validatorCount += 1;
                }

                if (mode === 'all') {
                    if (key.startsWith('CURRENT_BLOCK_') ||
                        key.startsWith('BLOCK_baseline_') ||
                        key.startsWith('BLOCK_proposed_')) {
                        keysToDelete.push(key);
                    }
                } else if (
                    key === getBlockStateKey(mode) ||
                    key.startsWith(`BLOCK_${mode}_`)
                ) {
                    keysToDelete.push(key);
                }
            }

            if (item.done) {
                await iterator.close();
                break;
            }
        }

        for (const key of keysToDelete) {
            await ctx.stub.deleteState(key);
        }

        return JSON.stringify({
            message:
                `Reset ${validatorCount} validators and cleared ` +
                `${keysToDelete.length} experiment-state records`,
            mode
        });
    }

    async _finalizeBlockState(ctx, blockState) {
        const result = await this.updateValidatorForBlock(
            ctx,
            blockState.validatorId,
            blockState.txCount,
            blockState.totalLatency,
            blockState.successCount
        );

        const validatorKey = getValidatorKey(blockState.validatorId);
        const validatorBytes = await ctx.stub.getState(validatorKey);
        const validator = JSON.parse(validatorBytes.toString());
        validator.selectionCount += 1;
        await ctx.stub.putState(
            validatorKey,
            Buffer.from(JSON.stringify(validator))
        );

        const record = {
            type: 'BLOCK_RECORD',
            mode: blockState.mode,
            blockNumber: blockState.blockNumber,
            validatorId: blockState.validatorId,
            txCount: blockState.txCount,
            blockAvgLatency:
                blockState.totalLatency / blockState.txCount,
            blockSuccessRate:
                blockState.successCount / blockState.txCount,
            validatorReputation: result.updatedReputation,
            validatorSuccessRate: result.successRate,
            validatorAvgLatency: result.avgLatency,
            correctnessScore: result.correctnessScore,
            latencyScore: result.latencyScore,
            historyScore: result.historyScore,
            reward: result.reward,
            ledgerTxId: ctx.stub.getTxID()
        };

        await ctx.stub.putState(
            getBlockRecordKey(blockState.mode, blockState.blockNumber),
            Buffer.from(JSON.stringify(record))
        );

        return record;
    }

    async _getValidatorObjects(ctx) {
        const iterator = await ctx.stub.getStateByRange(
            'VALIDATOR_',
            'VALIDATOR_\uffff'
        );
        const validators = [];

        while (true) {
            const item = await iterator.next();
            if (item.value && item.value.value) {
                validators.push(
                    JSON.parse(item.value.value.toString())
                );
            }
            if (item.done) {
                await iterator.close();
                break;
            }
        }

        validators.sort((a, b) => this._compareValidatorIds(a.id, b.id));
        return validators;
    }

    _normalizeMode(mode) {
        const normalized = String(mode || '').toLowerCase();
        if (normalized !== 'baseline' && normalized !== 'proposed') {
            throw new Error('mode must be baseline or proposed');
        }
        return normalized;
    }

    _compareValidatorIds(left, right) {
        const leftNumber = Number(String(left).replace(/\D/g, ''));
        const rightNumber = Number(String(right).replace(/\D/g, ''));
        if (Number.isFinite(leftNumber) &&
            Number.isFinite(rightNumber) &&
            leftNumber !== rightNumber) {
            return leftNumber - rightNumber;
        }
        return String(left).localeCompare(String(right));
    }

    _deterministicFraction(seed) {
        const digest = crypto
            .createHash('sha256')
            .update(seed)
            .digest('hex');
        const numerator = parseInt(digest.slice(0, 13), 16);
        const denominator = parseInt('fffffffffffff', 16);
        return numerator / denominator;
    }
}

module.exports = V2VContract;
